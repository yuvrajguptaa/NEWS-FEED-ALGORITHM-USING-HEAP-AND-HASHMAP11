# 📰 Feedify

**Feedify** is a real-time, country-based news feed web app that uses DSA algorithms like **Heap** and **Hashing** to sort, score, and simulate engagement with live news articles. It features search, trending keywords, dark/light mode, and even C++-style hashing logic to simulate "likes" in a creative way.

---

## 🌟 Features

- ✅ Live News Feed using NewsAPI  
- ✅ Country Selector (US 🇺🇸 | UK 🇬🇧 | India 🇮🇳)  
- ✅ Heap-based news ranking by weighted likes  
- ✅ HashMap for URL de-duplication  
- ✅ C++-style hashing to simulate **likes**  
- ✅ Real-time search filter  
- ✅ Trending topics generator  
- ✅ Light/Dark Mode toggle  
- ✅ Login/Signup UI styled with TailwindCSS  
- ✅ Responsive layout  

---

## 🧠 Tech Stack

| Layer      | Technology                     |
|------------|---------------------------------|
| Frontend   | HTML, CSS, JavaScript           |
| UI Styles  | Custom CSS + TailwindCSS        |
| Backend    | C++ (for hashing likes logic)   |
| API        | [NewsAPI.org](https://newsapi.org/) |
| Data       | Heap, HashMap, URL Hashing      |

---

## 📁 Folder Structure

feedify/
├── index.html # Main homepage
├── login.html # Login/Signup form
├── contact.html # Contact page
├── about.html # About project
├── utils.js # JS logic (hashing, render, filters, etc.)
├── style.css # Optional extra styles
├── hashLikes.cpp # C++ logic for hashing URLs into likes
├── README.md # You are here

yaml
Copy
Edit

---

## 🚀 How to Run This Project

1. **Clone the repo**:
   ```bash
   git clone https://github.com/yourusername/feedify.git
   cd feedify
Open the frontend:
Just open index.html in Chrome or any browser.

Simulate C++ logic (Optional):
If you want to test the C++ hash-based like simulation:

bash
Copy
Edit
g++ hashLikes.cpp -o likeHash
./likeHash
News API Setup:

Create an account at https://newsapi.org

Replace the API_KEY in the <script> tag in index.html:

js
Copy
Edit
const API_KEY = "your_news_api_key_here";
