function processArticle(article) {
  const categories = {
    technology: 1.5,
    business: 1.2,
    entertainment: 1.3,
    sports: 1.4,
    science: 1.2,
    health: 1.1,
    general: 1.0
  };

  const detectedCategory = detectCategory(article);
  const categoryWeight = categories[detectedCategory] || 1.0;

  return {
    ...article,
    category: detectedCategory,
    categoryWeight,
    likes: generateRandomLikes(article.url)
  };
}

// Detects category based on article title
function detectCategory(article) {
  const title = article.title.toLowerCase();
  if (title.includes('tech') || title.includes('ai') || title.includes('apple')) return 'technology';
  if (title.includes('sport') || title.includes('game') || title.includes('match')) return 'sports';
  if (title.includes('movie') || title.includes('celebrity') || title.includes('show')) return 'entertainment';
  return 'general';
}

// Simulates backend C++ hashing algorithm to generate likes
function generateRandomLikes(url) {
  return cppHashLike(url); // Simulated backend hash call
}

// Hash function (same as C++ logic)
function cppHashLike(url) {
  let hash = 0;
  const mod = 1000000007;
  const base = 31;
  for (let i = 0; i < url.length; i++) {
    hash = (hash * base + url.charCodeAt(i)) % mod;
  }
  return hash % 500 + 50;
}

// Filters news based on search input
function filterNews() {
  const searchTerm = document.getElementById('search-input').value.toLowerCase();
  const filtered = allArticles.filter(article =>
    article.title.toLowerCase().includes(searchTerm) ||
    (article.description && article.description.toLowerCase().includes(searchTerm))
  );
  renderArticles(filtered);
}

// Renders articles with Like button
function renderArticles(articles) {
  const container = document.getElementById('news-container');
  container.innerHTML = '';

  articles.forEach(article => {
    const articleEl = document.createElement('div');
    articleEl.classList.add('article');

    const likeId = `like-count-${hashURL(article.url)}`;

    articleEl.innerHTML = `
      <h3>${article.title}</h3>
      <p>${article.description || ''}</p>
      <button onclick="likeArticle('${article.url}')">👍 Like</button>
      <span id="${likeId}">Likes: ${article.likes || 0}</span>
    `;

    container.appendChild(articleEl);
  });
}

// Sends like request to backend (placeholder for C++ API)
function likeArticle(url) {
  fetch('http://localhost:5000/like', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url })
  })
  .then(response => response.json())
  .then(data => {
    const likeId = `like-count-${hashURL(url)}`;
    document.getElementById(likeId).innerText = `Likes: ${data.likes}`;
  })
  .catch(err => console.error("Error liking article:", err));
}

// Hashes URL string to create unique ID (same as used in C++ logic)
function hashURL(url) {
  let hash = 0;
  const mod = 1000000007;
  const base = 31;
  for (let i = 0; i < url.length; i++) {
    hash = (hash * base + url.charCodeAt(i)) % mod;
  }
  return hash;
}
