class NewsHeap {
  constructor() {
    this.heap = [];
    this.urlMap = new Map();
  }

  insert(article) {
    if (!article.url || this.urlMap.has(article.url)) return;
    article.score = (article.likes || 0) * (article.categoryWeight || 1.0);
    this.heap.push(article);
    this.urlMap.set(article.url, true);
    this.heapifyUp(this.heap.length - 1);
  }

  heapifyUp(index) {
    while (index > 0) {
      const parentIndex = Math.floor((index - 1) / 2);
      if (this.heap[parentIndex].score >= this.heap[index].score) break;
      [this.heap[parentIndex], this.heap[index]] = [this.heap[index], this.heap[parentIndex]];
      index = parentIndex;
    }
  }

  getTopArticles(k) {
    return [...this.heap].sort((a, b) => b.score - a.score).slice(0, k);
  }
}
