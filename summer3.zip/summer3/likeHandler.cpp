// File: likeHandler.cpp
// Compile: g++ likeHandler.cpp -o likeApp
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>
using namespace std;

unordered_map<string, int> likes;

int getLikes(string url) {
    ifstream infile("likes.txt");
    string line;
    while (getline(infile, line)) {
        size_t sep = line.find('|');
        if (sep != string::npos) {
            string storedUrl = line.substr(0, sep);
            int count = stoi(line.substr(sep + 1));
            likes[storedUrl] = count;
        }
    }
    infile.close();

    likes[url]++;

    ofstream outfile("likes.txt");
    for (const auto& entry : likes) {
        outfile << entry.first << "|" << entry.second << endl;
    }

    return likes[url];
}

int main() {
    string url;
    cout << "Enter URL to like: ";
    cin >> url;

    int updatedLikes = getLikes(url);
    cout << "Updated Likes: " << updatedLikes << endl;

    return 0;
}
