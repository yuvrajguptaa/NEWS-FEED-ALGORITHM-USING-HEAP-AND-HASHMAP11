// File: hashLikes.cpp
// Description: Simulates backend hashing logic to generate 'likes' from a URL
// Demonstrates string hashing using DSA principles (mod and base)

#include <iostream>
#include <string>
using namespace std;

// Function to hash a URL string and generate a like count
int generateLikesFromURL(const string& url) {
    const int base = 31;
    const int mod = 1e9 + 7;  // Large prime for hashing
    long long hash = 0;

    for (char c : url) {
        hash = (hash * base + c) % mod;
    }

    int likes = hash % 500 + 50; // Keep it in range [50, 549]
    return likes;
}

int main() {
    string url;
    cout << "Enter article URL: ";
    cin >> url;

    int likes = generateLikesFromURL(url);
    cout << "Generated Likes: " << likes << endl;

    return 0;
}
