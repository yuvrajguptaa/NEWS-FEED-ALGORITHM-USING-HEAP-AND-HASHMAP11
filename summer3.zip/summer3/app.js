document.addEventListener('DOMContentLoaded', () => {
  fetchAndRankNews();
  document.getElementById('country-select').addEventListener('change', fetchAndRankNews);
  document.getElementById('search-input').addEventListener('input', filterNews);
});

const API_KEY = "65820329280f4c8499d76e29a8fefb5c";
let allArticles = [];

async function fetchAndRankNews() {
  const country = document.getElementById('country-select').value;

  try {
    const response = await fetch(`https://newsapi.org/v2/top-headlines?country=${country}&apiKey=${API_KEY}`);
    const data = await response.json();

    const newsHeap = new NewsHeap();
    data.articles.forEach(article => {
      newsHeap.insert(processArticle(article));
    });

    allArticles = newsHeap.getTopArticles(20);
    renderArticles(allArticles);
  } catch (error) {
    console.error("Error fetching news:", error);
    document.getElementById('news-container').innerHTML = `
      <div class="error">
        <p>Failed to load news. Please try again later.</p>
      </div>
    `;
  }
}

function renderArticles(articles) {
  const container = document.getElementById('news-container');
  container.innerHTML = articles.map(article => `
    <div class="news-card">
      <img src="${article.urlToImage || 'https://via.placeholder.com/300x180'}" alt="${article.title}">
      <div class="content">
        <h3>${article.title}</h3>
        <p>${article.description || 'No description available.'}</p>
        <div class="article-meta">
          <span>${formatDate(article.publishedAt)}</span>
          <a href="${article.url}" target="_blank">Read More</a>
        </div>
      </div>
    </div>
  `).join('');
}
